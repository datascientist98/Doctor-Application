package com.example.doctor_application;

public class Member {
    private String Patient_Name;
    private String Doctor_Name;
    private String Date;
    private String Time;
    private String Add_Info;

    public Member() {
    }

    public String getPatient_Name() {
        return Patient_Name;
    }

    public void setPatient_Name(String patient_Name) {
        Patient_Name = patient_Name;
    }

    public String getDoctor_Name() {
        return Doctor_Name;
    }

    public void setDoctor_Name(String doctor_Name) {
        Doctor_Name = doctor_Name;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getAdd_Info() {
        return Add_Info;
    }

    public void setAdd_Info(String add_Info) {
        Add_Info = add_Info;
    }
}
