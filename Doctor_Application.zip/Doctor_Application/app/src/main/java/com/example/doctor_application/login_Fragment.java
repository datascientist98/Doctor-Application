
package com.example.doctor_application;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class login_Fragment extends Fragment {
    EditText text1, text2;
    Button login_btn;
    DatabaseReference reff;
    Login login;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.loginpage,container,false);
        Button btn = (Button)view.findViewById(R.id.sign_up_button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fr = getFragmentManager().beginTransaction();
                FragmentTransaction replace = fr.replace(R.id.fragment_container, new register_Fragment());
                fr.commit();
            }
        });
        text1 = (EditText) view.findViewById(R.id.text1);
        text2 = (EditText) view.findViewById(R.id.text2);
        login_btn = (Button) view.findViewById(R.id.b2);
        login = new Login();
        reff = FirebaseDatabase.getInstance().getReference().child("Login");
        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                login.setUsername(text1.getText().toString().trim());
                login.setPassword(text2.getText().toString().trim());
                reff.push().setValue(login);
                Toast.makeText(getContext(), "Logged In!", Toast.LENGTH_LONG).show();
            }
        });
        return view;


    }
    public interface OnFragmentInteractionListener{

        void onFragmentInteraction(Uri uri);
    }
}
