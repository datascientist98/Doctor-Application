package com.example.doctor_application;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
public class Book_Appointment extends AppCompatActivity {
    EditText text1,text2,text3,text4,text5;
    Button book;
    DatabaseReference reff;
    Member member;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_book);
        text1 = (EditText)findViewById(R.id.text1);
        text2 = (EditText)findViewById(R.id.text2);
        text3 = (EditText)findViewById(R.id.text3);
        text4 = (EditText)findViewById(R.id.text4);
        text5 = (EditText)findViewById(R.id.text5);
        book = (Button)findViewById(R.id.book1);
        member = new Member();
        reff = FirebaseDatabase.getInstance().getReference().child("Member");
        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "hello", Toast.LENGTH_LONG).show();
                member.setPatient_Name(text1.getText().toString().trim());
                member.setDoctor_Name(text2.getText().toString().trim());
                member.setDate(text3.getText().toString().trim());
                member.setTime(text4.getText().toString().trim());
                member.setAdd_Info(text5.getText().toString().trim());
                reff.push().setValue(member);
                Toast.makeText(Book_Appointment.this, "Appointment Booked Successfully", Toast.LENGTH_LONG).show();

            }
        });

    }
}
