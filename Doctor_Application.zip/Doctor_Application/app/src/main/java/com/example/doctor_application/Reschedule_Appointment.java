package com.example.doctor_application;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Reschedule_Appointment extends AppCompatActivity {
    EditText text1,text2,text3,text4,text5,text6;
    Button btn_reschedule;
    DatabaseReference reff;
    Member2 member;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_reschedule__appt);
        text1 = (EditText)findViewById(R.id.rtext1);
        text2 = (EditText)findViewById(R.id.rtext2);
        text3 = (EditText)findViewById(R.id.rtext3);
        text4 = (EditText)findViewById(R.id.rtext4);
        text5 = (EditText)findViewById(R.id.rtext5);
        text6 = (EditText)findViewById(R.id.rtext6);
        btn_reschedule = (Button)findViewById(R.id.btn_reschedule);
        member = new Member2();
        reff = FirebaseDatabase.getInstance().getReference().child("Member2");
        btn_reschedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                member.setPatient_Name(text1.getText().toString().trim());
                member.setDoctor_Name(text2.getText().toString().trim());
                member.setPrev_Date(text3.getText().toString().trim());
                member.setNew_Date(text4.getText().toString().trim());
                member.setTime(text5.getText().toString().trim());
                member.setAdd_Info(text6.getText().toString().trim());
                reff.push().setValue(member);
                Toast.makeText(Reschedule_Appointment.this, "Appointment Booked Successfully", Toast.LENGTH_LONG).show();

            }
        });

    }
}
