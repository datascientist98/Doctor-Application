package com.example.doctor_application;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class View_Appt extends AppCompatActivity {
EditText a,b,c,d,e;
Button btn;
DatabaseReference reff;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_view);

        a=(EditText) findViewById(R.id.text1);
        b=(EditText) findViewById(R.id.text2);
        c=(EditText) findViewById(R.id.text3);
        d=(EditText) findViewById(R.id.text4);
        e=(EditText) findViewById(R.id.text5);
        btn =(Button)findViewById(R.id.book1);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reff = FirebaseDatabase.getInstance().getReference().child("Member").child("-LrlHi9LWKQsUMnLXmxY");
                reff.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String patient_Name = dataSnapshot.child("patient_Name").getValue().toString();
                        String doctor_Name = dataSnapshot.child("doctor_Name").getValue().toString();
                        String date = dataSnapshot.child("date").getValue().toString();
                        String time = dataSnapshot.child("time").getValue().toString();
                        String add_Info = dataSnapshot.child("add_Info").getValue().toString();
                        a.setText(patient_Name);
                        b.setText(doctor_Name);
                        c.setText(date);
                        d.setText(time);
                        e.setText(add_Info);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });

    }
}
