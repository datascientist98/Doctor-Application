package com.example.doctor_application;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class ActivitySignUp extends AppCompatActivity {
    public EditText emailId, passwd;
    Button btnSignUp;
    TextView signIn;
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        firebaseAuth = FirebaseAuth.getInstance();
        emailId = findViewById(R.id.ETemail);
        passwd = findViewById(R.id.ETpassword);
        btnSignUp = findViewById(R.id.btnSignUp);
        //signIn = findViewById(R.id.TVSignIn);
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String emailID = emailId.getText().toString();
                String paswd = passwd.getText().toString();
                if (emailID.isEmpty()) {
                    emailId.setError("Please Enter Your Email ID!");
                    emailId.requestFocus();
                }
                else if (paswd.isEmpty()) {
                    passwd.setError("Please Enter Your Password!");
                    passwd.requestFocus();
                }
                else if (emailID.isEmpty() && paswd.isEmpty()) {
                    Toast.makeText(ActivitySignUp.this, "Fields Empty!", Toast.LENGTH_SHORT).show();
                }
                else if (!(emailID.isEmpty() && paswd.isEmpty())) {
                    firebaseAuth.createUserWithEmailAndPassword(emailID, paswd).addOnCompleteListener(ActivitySignUp.this, new OnCompleteListener< AuthResult>(){
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if (!task.isSuccessful()) {
                                Toast.makeText(ActivitySignUp.this,
                                        "SignUp unsuccessful, please try again",
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                startActivity(new Intent(ActivitySignUp.this, ActivityLogin.class));
                            }
                        }
                    });
                }
                else {
                    Toast.makeText(ActivitySignUp.this, "Error", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}