package com.example.doctor_application;

import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;

import static com.example.doctor_application.R.id;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, Book_Appointment_Fragment.OnFragmentInteractionListener {
    private Button button;
    private DrawerLayout drawer;
    private TextView textView;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(id.fragment_container, new login_Fragment());
        fragmentTransaction.add(id.fragment_container, new register_Fragment());
        fragmentTransaction.commit();


        Toolbar toolbar = findViewById(id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(id.drawer_layout);
        NavigationView navigationView = findViewById(id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener((DrawerLayout.DrawerListener) toggle);

        toggle.syncState();
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(id.fragment_container,
                    new About_Us_Fragment()).commit();
            navigationView.setCheckedItem(id.nav_aboutus);
        }


    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_aboutus:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new About_Us_Fragment()).commit();
                break;
            case R.id.nav_services:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new Services_Fragment()).commit();
                break;
            case R.id.nav_testimonials:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new Testimonials_Fragment()).commit();
                break;
            case R.id.nav_bookappt:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new Book_Appointment_Fragment()).commit();
                break;
            case R.id.nav_reschappt:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new Reschedule_Appointment_Fragment()).commit();
                break;
            case id.nav_viewappt:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new View_Appointment_Fragment()).commit();
                break;
            case R.id.nav_locateus:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new LocateUs_Fragment()).commit();
                break;
            case id.nav_camera:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new Camera_Fragment()).commit();
                break;
            case id.nav_logout:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new Logout_Fragment()).commit();
                break;
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}